-------------------------------------------------
fx_version 'adamant'
game 'gta5'
-------------------------------------------------
description 'FiveM Script Owned By Chudoku#2434'
-------------------------------------------------
client_scripts {
    '@NativeUI/NativeUI.lua',
    'config/config.lua',
    'whitelist/c_whitelist.lua',
    'heroes/electricman.lua',
    'heroes/exploder.lua',
    'heroes/invisibleman.lua',
    'heroes/quickster.lua',
    'heroes/superboy.lua',
    'heroes/vigilante.lua'
}
-------------------------------------------------
server_scripts {
    'whitelist/s_whitelist.lua',
    'heroes/_clientConnector.lua'
}
-------------------------------------------------