SuperboyConfig = {}

SuperboyConfig.MenuKey = 38

SuperboyConfig.Damage = 500.0

QuicksterConfig = {}

QuicksterConfig.MenuKey = 38

QuicksterConfig.Velocity = 3.00

QuicksterConfig.Damage = 100.0

InvisiblemanConfig = {}

InvisiblemanConfig.Strength = 100.0

InvisiblemanConfig.MenuKey = 38

ExploderConfig = {}

ExploderConfig.MenuKey = 38

ElectricConfig = {}

ElectricConfig.Velocity = 3.00

ElectricConfig.MenuKey = 38